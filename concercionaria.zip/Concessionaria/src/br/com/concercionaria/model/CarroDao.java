
package br.com.concercionaria.model;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CarroDao {
    
    private final SessionFactory conexao;
    
    public CarroDao(){
        conexao = new Configuration().configure().buildSessionFactory();
    }
    
    public void InserirCarro (Carro carro){
        Session session;
        session = conexao.openSession();
        Transaction tx = session.beginTransaction();
        session.save(carro);
        tx.commit();
        session.close();
    }
}
