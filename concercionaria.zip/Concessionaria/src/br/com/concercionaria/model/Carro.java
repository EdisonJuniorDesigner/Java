
package br.com.concercionaria.model;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Carro implements Serializable {
    
    @Id
    private int id;
    private String nomeCarro;
    private String placa;
    private String modelo;

    /**
     * @return the nomeCarro
     */
    public String getNomeCarro() {
        return nomeCarro;
    }

    /**
     * @param nomeCarro the nomeCarro to set
     */
    public void setNomeCarro(String nomeCarro) {
        this.nomeCarro = nomeCarro;
    }

    /**
     * @return the placa
     */
    public String getPlaca() {
        return placa;
    }

    /**
     * @param placa the placa to set
     */
    public void setPlaca(String placa) {
        this.placa = placa;
    }

    /**
     * @return the modelo
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * @param modelo the modelo to set
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

}
