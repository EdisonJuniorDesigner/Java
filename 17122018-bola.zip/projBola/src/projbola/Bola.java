package projbola;

public class Bola {
    private String cor;
    public float circunferencia;
    public String material;
    
    public void trocarCor(String novaCor){
        if (!novaCor.equals("")){
            cor = novaCor;
        }
    }
    
    public String mostraCor(){
        return cor;
    }
    
}
