
package projbola;

import java.util.Scanner;

public class Principal {


    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);
        Bola bola = new Bola();
        
        System.out.println("Nova cor: ");
        bola.trocarCor(x.next());
        
        System.out.println("Circunferência: ");
        bola.circunferencia = x.nextFloat();
        
        System.out.println("Material: ");
        bola.material = x.next();
        
        System.out.println(""
                + "Cor: " + bola.mostraCor()+"\n"
                + "Circunferencia: "+ bola.circunferencia + "\n"
                + "Material: " + bola.material + "\n");
    }
    
}
